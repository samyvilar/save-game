
Enables editing of `ForeignKey`, `ManyToMany` and simple text fields using the Autocomplete - `jQuery` plugin.

django-ajax-selects will work in any normal form as well as in the admin.

See docs.txt

